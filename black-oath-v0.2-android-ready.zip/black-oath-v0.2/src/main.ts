import Phaser from 'phaser';
import './style.css';
import { BattleScene } from './game/scenes/BattleScene';
import { ITEMS, randomItem } from './game/data/items';
import { botIntel, randomBot } from './game/data/bots';
import { huntChoices, type HuntDef } from './game/data/monsters';
import type { BattleSnapshot, FighterConfig, ItemId } from './game/sim/types';

const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = `
  <div id="game-wrap">
    <div id="phaser-root"></div>
    <div id="ui-root"></div>
  </div>
`;

const scene = new BattleScene();
new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'phaser-root',
  backgroundColor: '#050914',
  scene: [scene],
  scale: {
    mode: Phaser.Scale.RESIZE,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    width: 430,
    height: 760,
  },
  render: { antialias: false, pixelArt: true, roundPixels: true },
});

const ui = document.querySelector<HTMLDivElement>('#ui-root')!;
const TARGET_WINS = 4;

type RunPhase =
  | 'menu'
  | 'choice'
  | 'merchant'
  | 'replace'
  | 'hunt'
  | 'scout'
  | 'battle'
  | 'result'
  | 'gameover';

type RunState = {
  cycle: number;
  wins: number;
  resolve: number;
  gold: number;
  maxHp: number;
  corruption: number;
  items: ItemId[];
  upgrades: number[];
  phase: RunPhase;
  step: number;
};

type BattleKind = 'hunt' | 'duel';

let run: RunState = freshRun();
let pendingBot: FighterConfig | null = null;
let pendingIntel: string[] | null = null;
let currentBattleKind: BattleKind = 'duel';
let currentHunt: HuntDef | null = null;
let selectedBoardIndex: number | null = null;

function freshRun(): RunState {
  return {
    cycle: 1,
    wins: 0,
    resolve: 8,
    gold: 10,
    maxHp: 100,
    corruption: 0,
    items: ['vela_funeraria', 'lamina_desgastada', 'corrente_ferro', 'lanterna_negra'],
    upgrades: [0, 0, 0, 0],
    phase: 'menu',
    step: 0,
  };
}

function playerConfig(): FighterConfig {
  return {
    nome: 'O Errante',
    maxHp: run.maxHp,
    itemIds: [...run.items],
    upgrades: [...run.upgrades],
  };
}

function header() {
  return `
    <header class="hud-top">
      <div><span>CICLO</span><strong>${run.cycle}</strong></div>
      <div><span>VITÓRIAS</span><strong>${run.wins}/${TARGET_WINS}</strong></div>
      <div><span>OURO</span><strong>${run.gold}</strong></div>
      <div class="corruption"><span>CORRUPÇÃO</span><strong>${run.corruption}</strong></div>
      <div><span>DETERMINAÇÃO</span><strong>${run.resolve}</strong></div>
    </header>
  `;
}

function progressBar() {
  const names = ['ESCOLHA', 'ESCOLHA', 'CAÇADA', 'ESCOLHA', 'DUELO'];
  return `
    <div class="run-progress">
      ${names.map((name, i) => `<span class="${i < run.step ? 'done' : i === run.step ? 'current' : ''}">${name}</span>`).join('')}
    </div>
  `;
}

function symbolFor(id: ItemId) {
  const symbols: Record<ItemId, string> = {
    lamina_desgastada: '†',
    vela_funeraria: '✣',
    corrente_ferro: '≋',
    lanterna_negra: '◈',
    machado_carrasco: '⚒',
    estrela_adormecida: '✦',
    ampulheta_sem_areia: '⌛',
    segundo_coracao: '♥',
    porta_lugar_nenhum: '⌑',
    verme_amanha: '∿',
    frasco_meia_noite: '◐',
    fragmento_sol_morto: '☼',
  };
  return symbols[id];
}

function rarityClass(id: ItemId) {
  return ITEMS[id].raridade.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function itemCard(id: ItemId, index: number, snapshot?: BattleSnapshot, side: 'player' | 'enemy' = 'player') {
  const def = ITEMS[id];
  const fighter = side === 'player' ? snapshot?.player : snapshot?.enemy;
  const state = fighter?.items[index];
  const full = def.cooldown * (state?.cooldownMultiplier ?? 1);
  const pct = def.effect && state ? Math.max(0, Math.min(100, 100 * (1 - state.remaining / full))) : 100;
  const disabled = state && state.disabledUntil > (snapshot?.time ?? 0);
  const level = side === 'player' ? (run.upgrades[index] ?? 0) : 0;
  return `
    <article class="item-card ${rarityClass(id)} ${disabled ? 'disabled' : ''}" data-index="${index}">
      <div class="item-topline"><span>${def.categoria}</span><span>${def.raridade}</span></div>
      <div class="item-symbol">${symbolFor(id)}</div>
      <div class="item-name">${def.nome}${side === 'player' && level > 0 ? ` +${level}` : ''}</div>
      <div class="charge"><i style="width:${pct}%"></i></div>
      <small>${def.descricao}</small>
    </article>
  `;
}

function playerBoard(snapshot?: BattleSnapshot, interactive = false) {
  const fighter = snapshot?.player;
  return `
    <section class="board-panel">
      <div class="fighter-line">
        <div>
          <small>O ERRANTE</small>
          <strong>${fighter ? Math.ceil(fighter.hp) : run.maxHp}/${run.maxHp} VIDA</strong>
        </div>
        <b>${fighter ? Math.round(fighter.shield) : 0} ESCUDO</b>
      </div>
      <div class="board-grid ${interactive ? 'interactive' : ''}">
        ${run.items.map((id, index) => itemCard(id, index, snapshot)).join('')}
      </div>
    </section>
  `;
}

function enemyBoard(config: FighterConfig, snapshot?: BattleSnapshot) {
  return `
    <section class="enemy-board">
      ${config.itemIds.map((id, index) => {
        const def = ITEMS[id];
        const state = snapshot?.enemy.items[index];
        const full = def.cooldown * (state?.cooldownMultiplier ?? 1);
        const pct = def.effect && state ? Math.max(0, Math.min(100, 100 * (1 - state.remaining / full))) : 100;
        return `
          <div class="enemy-item ${rarityClass(id)}">
            <span>${symbolFor(id)}</span>
            <b>${def.nome}</b>
            <i><em style="width:${pct}%"></em></i>
          </div>
        `;
      }).join('')}
    </section>
  `;
}

function setBg(key: 'cathedral' | 'forest' | 'camp' | 'fortress') {
  scene.setBackground(key);
}

function showMenu() {
  run.phase = 'menu';
  setBg('camp');
  ui.innerHTML = `
    <main class="screen menu-screen">
      <div class="title-block">
        <div class="sigil">◈</div>
        <h1>BLACK OATH</h1>
        <p>Uma run. Escolhas incertas. Um juramento que cobra o preço.</p>
      </div>
      <button class="primary" id="start">INICIAR RUN</button>
      <small class="version">Protótipo v0.2</small>
    </main>
  `;
  document.querySelector('#start')?.addEventListener('click', () => {
    run = freshRun();
    startCycle();
  });
}

function startCycle() {
  run.step = 0;
  selectedBoardIndex = null;
  showChoice();
}

function advanceFlow() {
  run.step += 1;
  if (run.resolve <= 0) return showGameOver(false);
  if (run.step === 2) return showHunt();
  if (run.step >= 4) return showScout();
  showChoice();
}

type EventId = 'smith' | 'merchant' | 'well' | 'forest' | 'chapel' | 'blood';
const EVENT_META: Record<EventId, { nome: string; descricao: string; efeito: string }> = {
  smith: { nome: 'Ferreiro Silencioso', descricao: 'Metal frio ainda responde ao martelo.', efeito: 'Melhore um item' },
  merchant: { nome: 'Mercador Errante', descricao: 'Quatro rodas, nenhum cavalo, muitas perguntas.', efeito: 'Compre um item' },
  well: { nome: 'Poço dos Sussurros', descricao: 'A água conhece seu nome antes de você falar.', efeito: '+7 Ouro, -10 Vida Máx.' },
  forest: { nome: 'Bosque Retorcido', descricao: 'Algo impossível pulsa entre as raízes.', efeito: 'Encontre um item' },
  chapel: { nome: 'Capela Esquecida', descricao: 'Ainda existe luz, mas ela não é gratuita.', efeito: 'Purifique-se' },
  blood: { nome: 'Mercador de Sangue', descricao: 'Ele não aceita moedas.', efeito: 'Compre com Vida' },
};

function choicePool(): EventId[] {
  const all: EventId[] = ['smith', 'merchant', 'well', 'forest', 'chapel', 'blood'];
  return all.sort(() => Math.random() - 0.5).slice(0, 3);
}

function showChoice() {
  run.phase = 'choice';
  setBg('forest');
  const options = choicePool();
  ui.innerHTML = `
    ${header()}
    <main class="screen choice-screen">
      ${progressBar()}
      <div class="section-title">
        <small>O CAMINHO SE DIVIDE</small>
        <h2>Escolha onde entrar</h2>
      </div>
      <div class="choices">
        ${options.map((id) => {
          const meta = EVENT_META[id];
          return `
            <button class="choice" data-event="${id}">
              <div class="choice-rune">${eventRune(id)}</div>
              <b>${meta.nome}</b>
              <span>${meta.descricao}</span>
              <em>${meta.efeito}</em>
            </button>
          `;
        }).join('')}
      </div>
      ${playerBoard()}
    </main>
  `;
  document.querySelectorAll<HTMLButtonElement>('[data-event]').forEach((button) => {
    button.addEventListener('click', () => resolveEvent(button.dataset.event as EventId));
  });
}

function eventRune(id: EventId) {
  return ({ smith: '⚒', merchant: '◇', well: '◉', forest: '♜', chapel: '✧', blood: '♥' } as const)[id];
}

function resolveEvent(id: EventId) {
  if (id === 'smith') return showUpgrade();
  if (id === 'merchant') return showMerchant(false);
  if (id === 'blood') return showMerchant(true);
  if (id === 'well') {
    run.maxHp = Math.max(45, run.maxHp - 10);
    run.gold += 7;
    run.corruption = Math.min(100, run.corruption + 7);
    return showEventResult('O poço bebeu uma parte de você.', '+7 Ouro · -10 Vida Máxima · +7 Corrupção');
  }
  if (id === 'forest') return showFoundItems();
  showChapel();
}

function showEventResult(title: string, text: string) {
  ui.innerHTML = `
    ${header()}
    <main class="screen centered-screen">
      <div class="result-emblem">◈</div>
      <h2>${title}</h2>
      <p>${text}</p>
      <button class="primary" id="event-continue">CONTINUAR</button>
    </main>
  `;
  document.querySelector('#event-continue')?.addEventListener('click', advanceFlow);
}

function showUpgrade() {
  run.phase = 'merchant';
  setBg('fortress');
  ui.innerHTML = `
    ${header()}
    <main class="screen shop-screen">
      ${progressBar()}
      <div class="section-title"><small>FERREIRO SILENCIOSO</small><h2>Escolha o metal</h2></div>
      <p class="hint">A melhoria aumenta em 15% os valores principais do item. Toque em um item.</p>
      ${playerBoard(undefined, true)}
      <button class="secondary" id="skip">IR EMBORA</button>
    </main>
  `;
  document.querySelectorAll<HTMLDivElement>('.board-grid.interactive .item-card').forEach((card) => {
    card.addEventListener('click', () => {
      const index = Number(card.dataset.index);
      const id = run.items[index];
      run.upgrades[index] = Math.min(3, (run.upgrades[index] ?? 0) + 1);
      showEventResult(`${ITEMS[id].nome} foi reforçado.`, `Nível de melhoria: +${run.upgrades[index]}.`);
    });
  });
  document.querySelector('#skip')?.addEventListener('click', advanceFlow);
}

function offers(count = 3) {
  const result: ItemId[] = [];
  while (result.length < count) {
    const id = randomItem(run.corruption, result);
    result.push(id);
  }
  return result;
}

function showMerchant(blood: boolean, shopItems: ItemId[] = offers(3)) {
  run.phase = 'merchant';
  setBg('camp');
  ui.innerHTML = `
    ${header()}
    <main class="screen shop-screen">
      ${progressBar()}
      <div class="section-title">
        <small>${blood ? 'MERCADOR DE SANGUE' : 'MERCADOR ERRANTE'}</small>
        <h2>${blood ? 'O preço não é ouro' : 'Algo lhe interessa?'}</h2>
      </div>
      <div class="shop-grid">
        ${shopItems.map((id) => {
          const item = ITEMS[id];
          const cost = blood ? bloodCost(id) : item.preco;
          return `
            <button class="shop-item ${rarityClass(id)}" data-buy="${id}" data-cost="${cost}">
              <span class="big-symbol">${symbolFor(id)}</span>
              <b>${item.nome}</b>
              <small>${item.descricao}</small>
              <em>${blood ? `${cost} Vida Máx.` : `${cost} Ouro`}</em>
            </button>
          `;
        }).join('')}
      </div>
      <button class="secondary" id="skip">NÃO COMPRAR</button>
    </main>
  `;
  document.querySelectorAll<HTMLButtonElement>('[data-buy]').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.buy as ItemId;
      const cost = Number(button.dataset.cost);
      if (!blood && run.gold < cost) return flashMessage('Ouro insuficiente.');
      if (blood && run.maxHp - cost < 45) return flashMessage('Você não sobreviveria ao preço.');
      chooseReplacement(id, () => {
        if (blood) {
          run.maxHp -= cost;
          run.corruption = Math.min(100, run.corruption + 6);
        } else run.gold -= cost;
        advanceFlow();
      }, blood ? `${cost} de Vida Máxima` : `${cost} de Ouro`, () => showMerchant(blood, shopItems));
    });
  });
  document.querySelector('#skip')?.addEventListener('click', advanceFlow);
}

function bloodCost(id: ItemId) {
  const rarity = ITEMS[id].raridade;
  return rarity === 'Lendário' ? 18 : rarity === 'Épico' ? 14 : rarity === 'Raro' ? 10 : 7;
}

function showFoundItems(found: ItemId[] = offers(3)) {
  setBg('forest');
  ui.innerHTML = `
    ${header()}
    <main class="screen shop-screen">
      ${progressBar()}
      <div class="section-title"><small>BOSQUE RETORCIDO</small><h2>Três coisas observaram você</h2></div>
      <p class="hint">Escolha uma. O bosque ficará dentro dela.</p>
      <div class="shop-grid">
        ${found.map((id) => `
          <button class="shop-item ${rarityClass(id)}" data-found="${id}">
            <span class="big-symbol">${symbolFor(id)}</span>
            <b>${ITEMS[id].nome}</b>
            <small>${ITEMS[id].descricao}</small>
            <em>+5 Corrupção</em>
          </button>
        `).join('')}
      </div>
    </main>
  `;
  document.querySelectorAll<HTMLButtonElement>('[data-found]').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.found as ItemId;
      chooseReplacement(id, () => {
        run.corruption = Math.min(100, run.corruption + 5);
        advanceFlow();
      }, 'sem custo de Ouro', () => showFoundItems(found));
    });
  });
}

function showChapel() {
  setBg('cathedral');
  ui.innerHTML = `
    ${header()}
    <main class="screen centered-screen">
      ${progressBar()}
      <div class="result-emblem">✧</div>
      <h2>Capela Esquecida</h2>
      <p>Uma chama branca ainda arde diante do altar rachado.</p>
      <div class="vertical-actions">
        <button class="choice-wide" id="cleanse"><b>TOCAR A CHAMA</b><span>-15 Corrupção</span></button>
        <button class="choice-wide" id="pray"><b>DEIXAR UMA MOEDA</b><span>-3 Ouro · +6 Vida Máxima</span></button>
      </div>
    </main>
  `;
  document.querySelector('#cleanse')?.addEventListener('click', () => {
    run.corruption = Math.max(0, run.corruption - 15);
    showEventResult('O ruído dentro da sua cabeça diminuiu.', '-15 Corrupção');
  });
  document.querySelector('#pray')?.addEventListener('click', () => {
    if (run.gold < 3) return flashMessage('Você não tem Ouro suficiente.');
    run.gold -= 3;
    run.maxHp += 6;
    showEventResult('A chama reconheceu a oferta.', '+6 Vida Máxima');
  });
}

function chooseReplacement(id: ItemId, onConfirm: () => void, costText: string, onCancel: () => void = showChoice) {
  run.phase = 'replace';
  ui.innerHTML = `
    ${header()}
    <main class="screen replace-screen">
      <div class="section-title"><small>NOVO ITEM</small><h2>${ITEMS[id].nome}</h2></div>
      <div class="new-item-preview ${rarityClass(id)}">
        <span>${symbolFor(id)}</span><b>${ITEMS[id].nome}</b><p>${ITEMS[id].descricao}</p><em>${costText}</em>
      </div>
      <p class="hint">Seu tabuleiro está cheio. Escolha o item que será substituído.</p>
      ${playerBoard(undefined, true)}
      <button class="secondary" id="cancel-replace">CANCELAR</button>
    </main>
  `;
  document.querySelectorAll<HTMLDivElement>('.board-grid.interactive .item-card').forEach((card) => {
    card.addEventListener('click', () => {
      const index = Number(card.dataset.index);
      run.items[index] = id;
      run.upgrades[index] = 0;
      onConfirm();
    });
  });
  document.querySelector('#cancel-replace')?.addEventListener('click', onCancel);
}

function showHunt() {
  run.phase = 'hunt';
  setBg('forest');
  const choices = huntChoices(run.cycle, run.corruption);
  ui.innerHTML = `
    ${header()}
    <main class="screen hunt-screen">
      ${progressBar()}
      <div class="section-title"><small>CAÇADA</small><h2>Escolha o que seguir</h2></div>
      <div class="hunt-list">
        ${choices.map((hunt, index) => `
          <button class="hunt-card perigo-${hunt.perigo.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')}" data-hunt="${index}">
            <div><span>${hunt.perigo}</span><b>${hunt.nome}</b></div>
            <p>${hunt.descricao}</p>
            <em>Recompensa: ${hunt.reward.gold} Ouro${hunt.reward.itemChance ? ' · chance de item' : ''}</em>
          </button>
        `).join('')}
      </div>
      ${playerBoard()}
    </main>
  `;
  document.querySelectorAll<HTMLButtonElement>('[data-hunt]').forEach((button) => {
    button.addEventListener('click', () => {
      currentHunt = choices[Number(button.dataset.hunt)];
      startBattle('hunt', currentHunt.config);
    });
  });
}

function showScout() {
  run.phase = 'scout';
  setBg('fortress');
  if (!pendingBot) pendingBot = randomBot(run.cycle, run.corruption);
  if (!pendingIntel) pendingIntel = botIntel(pendingBot).sort(() => Math.random() - 0.5).slice(0, 2);
  const intel = pendingIntel;
  ui.innerHTML = `
    ${header()}
    <main class="screen scout-screen">
      ${progressBar()}
      <div class="section-title"><small>O CORVO RETORNOU</small><h2>Ele viu alguma coisa</h2></div>
      <div class="intel-box">${intel.map((x) => `<p>◈ ${x}</p>`).join('')}</div>
      <p class="hint">Toque em dois itens para trocar suas posições antes do Duelo.</p>
      ${playerBoard(undefined, true)}
      <button class="primary" id="duel">INICIAR DUELO</button>
    </main>
  `;
  const cards = document.querySelectorAll<HTMLDivElement>('.board-grid.interactive .item-card');
  cards.forEach((card) => {
    const index = Number(card.dataset.index);
    if (selectedBoardIndex === index) card.classList.add('selected');
    card.addEventListener('click', () => {
      if (selectedBoardIndex === null) {
        selectedBoardIndex = index;
        showScout();
      } else if (selectedBoardIndex === index) {
        selectedBoardIndex = null;
        showScout();
      } else {
        [run.items[selectedBoardIndex], run.items[index]] = [run.items[index], run.items[selectedBoardIndex]];
        [run.upgrades[selectedBoardIndex], run.upgrades[index]] = [run.upgrades[index], run.upgrades[selectedBoardIndex]];
        selectedBoardIndex = null;
        showScout();
      }
    });
  });
  document.querySelector('#duel')?.addEventListener('click', () => {
    selectedBoardIndex = null;
    startBattle('duel', pendingBot!);
  });
}

function startBattle(kind: BattleKind, enemy: FighterConfig) {
  run.phase = 'battle';
  currentBattleKind = kind;
  setBg(kind === 'duel' ? 'cathedral' : 'forest');
  scene.startBattle(playerConfig(), enemy);
  battleLoop();
}

function battleLoop() {
  const snap = scene.getSnapshot();
  const configs = scene.getConfigs();
  if (!snap || !configs.enemy) {
    requestAnimationFrame(battleLoop);
    return;
  }
  const enemy = snap.enemy;
  const events = snap.events.slice(-5);
  ui.innerHTML = `
    ${header()}
    <main class="screen battle-screen">
      <section class="enemy-panel">
        <div><small>${currentBattleKind === 'duel' ? 'ADVERSÁRIO' : 'CRIATURA'}</small><h2>${enemy.nome}</h2></div>
        <div class="enemy-stats"><b>${Math.ceil(enemy.hp)}/${enemy.maxHp}</b><span>${Math.round(enemy.shield)} Escudo</span></div>
      </section>
      ${enemyBoard(configs.enemy, snap)}
      <div class="battle-clock">${snap.time.toFixed(1)}s ${snap.time >= 30 ? '• CONDENAÇÃO' : ''}</div>
      ${playerBoard(snap)}
      <section class="combat-log">${events.map((e) => `<p class="${e.actor}">${e.text}</p>`).join('')}</section>
    </main>
  `;
  if (snap.finished) {
    window.setTimeout(() => finishBattle(snap.winner), 650);
    return;
  }
  requestAnimationFrame(battleLoop);
}

function finishBattle(winner: BattleSnapshot['winner']) {
  run.phase = 'result';
  const won = winner === 'player';
  if (currentBattleKind === 'hunt') {
    if (won && currentHunt) {
      run.gold += currentHunt.reward.gold;
      run.corruption = Math.min(100, run.corruption + (currentHunt.reward.corruption ?? 0));
      const itemDrop = Math.random() < (currentHunt.reward.itemChance ?? 0);
      if (itemDrop) {
        const found = randomItem(run.corruption);
        return showHuntReward(found, currentHunt.reward.gold);
      }
      return showBattleResult(true, `+${currentHunt.reward.gold} Ouro`, () => {
        currentHunt = null;
        advanceFlow();
      });
    }
    run.resolve -= 1;
    return showBattleResult(false, '-1 Determinação', () => {
      currentHunt = null;
      advanceFlow();
    });
  }

  if (won) {
    run.wins += 1;
    const reward = 5 + run.cycle;
    run.gold += reward;
    showBattleResult(true, `+${reward} Ouro`, afterDuel);
  } else {
    run.resolve -= 2;
    showBattleResult(false, '-2 Determinação', afterDuel);
  }
}

function showHuntReward(id: ItemId, gold: number) {
  ui.innerHTML = `
    ${header()}
    <main class="screen centered-screen">
      <div class="result-emblem">✦</div>
      <h2>A criatura deixou algo para trás</h2>
      <div class="new-item-preview ${rarityClass(id)}"><span>${symbolFor(id)}</span><b>${ITEMS[id].nome}</b><p>${ITEMS[id].descricao}</p></div>
      <p>Você também recebeu ${gold} de Ouro.</p>
      <div class="vertical-actions">
        <button class="primary" id="take-drop">SUBSTITUIR UM ITEM</button>
        <button class="secondary" id="leave-drop">DEIXAR PARA TRÁS</button>
      </div>
    </main>
  `;
  document.querySelector('#take-drop')?.addEventListener('click', () => chooseReplacement(id, () => {
    currentHunt = null;
    advanceFlow();
  }, 'recompensa da Caçada', () => showHuntReward(id, gold)));
  document.querySelector('#leave-drop')?.addEventListener('click', () => {
    currentHunt = null;
    advanceFlow();
  });
}

function showBattleResult(won: boolean, rewardText: string, next: () => void) {
  ui.innerHTML = `
    ${header()}
    <main class="screen result-screen">
      <div class="result-emblem">${won ? '✦' : '✕'}</div>
      <h1>${won ? 'VITÓRIA' : 'DERROTA'}</h1>
      <p>${rewardText}</p>
      <button class="primary" id="battle-next">CONTINUAR</button>
    </main>
  `;
  document.querySelector('#battle-next')?.addEventListener('click', next);
}

function afterDuel() {
  pendingBot = null;
  pendingIntel = null;
  if (run.resolve <= 0) return showGameOver(false);
  if (run.wins >= TARGET_WINS) return showGameOver(true);
  run.cycle += 1;
  startCycle();
}

function showGameOver(completed: boolean) {
  run.phase = 'gameover';
  setBg(completed ? 'fortress' : 'cathedral');
  ui.innerHTML = `
    ${header()}
    <main class="screen result-screen">
      <div class="result-emblem">${completed ? '✦' : '†'}</div>
      <h1>${completed ? 'RUN CONCLUÍDA' : 'O JURAMENTO TERMINOU'}</h1>
      <p>${completed ? `Você venceu ${run.wins} Duelos e chegou ao fim desta versão.` : `Você chegou ao Ciclo ${run.cycle} com ${run.wins} vitória(s).`}</p>
      <p class="summary">Corrupção final: ${run.corruption} · Ouro: ${run.gold}</p>
      <button class="primary" id="new-run">NOVA RUN</button>
    </main>
  `;
  document.querySelector('#new-run')?.addEventListener('click', () => {
    run = freshRun();
    startCycle();
  });
}

function flashMessage(text: string) {
  let toast = document.querySelector<HTMLDivElement>('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    ui.appendChild(toast);
  }
  toast.textContent = text;
  toast.classList.add('show');
  window.setTimeout(() => toast?.classList.remove('show'), 1200);
}

showMenu();
