import { ITEMS } from '../data/items';
import type { BattleEvent, BattleSnapshot, BoardItemState, FighterConfig, FighterState } from './types';

const cloneFighter = (f: FighterState): FighterState => ({
  ...f,
  items: f.items.map((item) => ({ ...item, def: { ...item.def } })),
});

function createFighter(config: FighterConfig): FighterState {
  const items: BoardItemState[] = config.itemIds.map((id, index) => {
    const level = config.upgrades?.[index] ?? 0;
    return {
      def: ITEMS[id],
      remaining: ITEMS[id].cooldown,
      cooldownMultiplier: 1,
      levelMultiplier: 1 + level * 0.15,
      disabledUntil: 0,
      charges: 0,
    };
  });

  items.forEach((item, index) => {
    if (item.def.passiveRightHaste && items[index + 1]) {
      items[index + 1].cooldownMultiplier *= 1 - item.def.passiveRightHaste;
      items[index + 1].remaining = items[index + 1].def.cooldown * items[index + 1].cooldownMultiplier;
    }
  });

  return {
    nome: config.nome,
    hp: config.maxHp,
    maxHp: config.maxHp,
    shield: 0,
    markUntil: 0,
    items,
    damageMultiplier: config.damageMultiplier ?? 1,
  };
}

function applyDamage(target: FighterState, amount: number, now: number): number {
  const marked = target.markUntil > now;
  let final = amount * (marked ? 1.15 : 1);
  final = Math.round(final * 10) / 10;
  const absorbed = Math.min(target.shield, final);
  target.shield -= absorbed;
  const hpDamage = final - absorbed;
  target.hp -= hpDamage;
  target.hp = Math.max(0, Math.round(target.hp * 10) / 10);
  return final;
}

export class BattleSimulation {
  private player: FighterState;
  private enemy: FighterState;
  private time = 0;
  private events: BattleEvent[] = [];
  private finished = false;
  private winner: BattleSnapshot['winner'] = null;
  private doomTick = 0;

  constructor(player: FighterConfig, enemy: FighterConfig) {
    this.player = createFighter(player);
    this.enemy = createFighter(enemy);
    this.events.push({ at: 0, actor: 'system', text: 'A batalha começou.' });
  }

  update(dt: number): BattleSnapshot {
    if (this.finished) return this.snapshot();
    this.time += dt;
    this.tickFighter(this.player, this.enemy, 'player', dt);
    if (!this.finished) this.tickFighter(this.enemy, this.player, 'enemy', dt);

    if (this.time >= 30 && !this.finished) {
      const nextTick = Math.floor(this.time - 30);
      if (nextTick > this.doomTick) {
        this.doomTick = nextTick;
        const doomDamage = this.doomTick * 5;
        applyDamage(this.player, doomDamage, this.time);
        applyDamage(this.enemy, doomDamage, this.time);
        this.events.push({ at: this.time, actor: 'system', text: `Condenação: ambos sofrem ${doomDamage} de dano.` });
        this.checkWinner();
      }
    }

    this.checkWinner();
    return this.snapshot();
  }

  private tickFighter(actor: FighterState, target: FighterState, actorName: 'player' | 'enemy', dt: number) {
    actor.items.forEach((item, index) => {
      if (!item.def.effect || this.finished) return;
      if (item.disabledUntil > this.time) return;
      if (item.def.activeBelowHpRatio && actor.hp / actor.maxHp > item.def.activeBelowHpRatio) return;
      item.remaining -= dt;
      if (item.remaining > 0) return;
      this.triggerItem(actor, target, actorName, index);
      item.remaining += item.def.cooldown * item.cooldownMultiplier;
    });
  }

  private triggerItem(actor: FighterState, target: FighterState, actorName: 'player' | 'enemy', index: number) {
    const itemState = actor.items[index];
    const item = itemState.def;
    const mult = itemState.levelMultiplier;
    const effect = item.effect!;

    if (effect.type === 'damage') {
      const value = Math.round(effect.amount * mult * actor.damageMultiplier);
      const dealt = applyDamage(target, value, this.time);
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} causou ${dealt} de dano.`, amount: dealt });
    } else if (effect.type === 'shield') {
      const value = Math.round(effect.amount * mult);
      actor.shield += value;
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} concedeu ${value} de Escudo.`, amount: value });
    } else if (effect.type === 'mark') {
      target.markUntil = Math.max(target.markUntil, this.time + effect.duration);
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} aplicou Marca por ${effect.duration}s.` });
    } else if (effect.type === 'advanceSlowest') {
      const candidates = actor.items.filter((x) => x.def.effect && x !== itemState && x.disabledUntil <= this.time);
      const slowest = [...candidates].sort((a, b) => b.remaining - a.remaining)[0];
      if (slowest) {
        slowest.remaining = Math.max(0.08, slowest.remaining - effect.seconds);
        this.events.push({ at: this.time, actor: actorName, text: `${item.nome} adiantou ${slowest.def.nome} em ${effect.seconds}s.` });
      }
    } else if (effect.type === 'selfDamageDamage') {
      const self = applyDamage(actor, effect.self, this.time);
      const dealt = applyDamage(target, effect.target * mult * actor.damageMultiplier, this.time);
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} tomou ${self} e arrancou ${dealt} de Vida.` });
    } else if (effect.type === 'banishEnemy') {
      const candidates = target.items.filter((x) => x.def.effect && x.disabledUntil <= this.time);
      const chosen = [...candidates].sort((a, b) => a.remaining - b.remaining)[0];
      if (chosen) {
        chosen.disabledUntil = this.time + effect.duration;
        this.events.push({ at: this.time, actor: actorName, text: `${item.nome} apagou ${chosen.def.nome} por ${effect.duration}s.` });
      }
    } else if (effect.type === 'accelerateAdjacent') {
      const left = actor.items[index - 1];
      const right = actor.items[index + 1];
      [left, right].forEach((adj) => { if (adj?.def.effect) adj.remaining = Math.max(0.08, adj.remaining - effect.seconds); });
      const dealt = applyDamage(target, 12 * mult * actor.damageMultiplier, this.time);
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} causou ${dealt} e devorou ${effect.seconds}s dos vizinhos.` });
    } else if (effect.type === 'accelerateCategory') {
      let affected = 0;
      actor.items.forEach((x) => {
        if (x !== itemState && x.def.categoria === effect.category && x.def.effect) {
          x.remaining = Math.max(0.08, x.remaining - effect.seconds);
          affected += 1;
        }
      });
      this.events.push({ at: this.time, actor: actorName, text: `${item.nome} adiantou ${affected} item(ns) ${effect.category}.` });
    } else if (effect.type === 'chargeBlast') {
      itemState.charges += 1;
      if (itemState.charges >= effect.charges) {
        itemState.charges = 0;
        const dealt = applyDamage(target, effect.amount * mult * actor.damageMultiplier, this.time);
        this.events.push({ at: this.time, actor: actorName, text: `${item.nome} rompeu o céu e causou ${dealt} de dano.` });
      } else {
        this.events.push({ at: this.time, actor: actorName, text: `${item.nome} acumulou uma carga (${itemState.charges}/${effect.charges}).` });
      }
    }
    this.checkWinner();
  }

  private checkWinner() {
    const pDead = this.player.hp <= 0;
    const eDead = this.enemy.hp <= 0;
    if (!pDead && !eDead) return;
    this.finished = true;
    if (pDead && eDead) this.winner = 'draw';
    else this.winner = eDead ? 'player' : 'enemy';
    this.events.push({
      at: this.time,
      actor: 'system',
      text: this.winner === 'player' ? 'Vitória.' : this.winner === 'enemy' ? 'Derrota.' : 'A batalha terminou empatada.',
    });
  }

  snapshot(): BattleSnapshot {
    return {
      time: this.time,
      player: cloneFighter(this.player),
      enemy: cloneFighter(this.enemy),
      events: [...this.events],
      finished: this.finished,
      winner: this.winner,
    };
  }
}
