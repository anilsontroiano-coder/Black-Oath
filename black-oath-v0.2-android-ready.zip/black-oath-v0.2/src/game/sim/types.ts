export type ItemId =
  | 'lamina_desgastada'
  | 'vela_funeraria'
  | 'corrente_ferro'
  | 'lanterna_negra'
  | 'machado_carrasco'
  | 'estrela_adormecida'
  | 'ampulheta_sem_areia'
  | 'segundo_coracao'
  | 'porta_lugar_nenhum'
  | 'verme_amanha'
  | 'frasco_meia_noite'
  | 'fragmento_sol_morto';

export type ItemCategory =
  | 'Arma'
  | 'Ritual'
  | 'Defesa'
  | 'Sombrio'
  | 'Cósmico'
  | 'Tempo'
  | 'Carne'
  | 'Vazio';

export type Rarity = 'Comum' | 'Raro' | 'Épico' | 'Lendário';

export type Effect =
  | { type: 'damage'; amount: number }
  | { type: 'shield'; amount: number }
  | { type: 'mark'; duration: number }
  | { type: 'advanceSlowest'; seconds: number }
  | { type: 'selfDamageDamage'; self: number; target: number }
  | { type: 'banishEnemy'; duration: number }
  | { type: 'accelerateAdjacent'; seconds: number }
  | { type: 'accelerateCategory'; category: ItemCategory; seconds: number }
  | { type: 'chargeBlast'; charges: number; amount: number };

export interface ItemDef {
  id: ItemId;
  nome: string;
  categoria: ItemCategory;
  raridade: Rarity;
  cooldown: number;
  preco: number;
  descricao: string;
  effect?: Effect;
  passiveRightHaste?: number;
  activeBelowHpRatio?: number;
}

export interface BoardItemState {
  def: ItemDef;
  remaining: number;
  cooldownMultiplier: number;
  levelMultiplier: number;
  disabledUntil: number;
  charges: number;
}

export interface FighterConfig {
  nome: string;
  maxHp: number;
  itemIds: ItemId[];
  upgrades?: number[];
  damageMultiplier?: number;
}

export interface FighterState {
  nome: string;
  hp: number;
  maxHp: number;
  shield: number;
  markUntil: number;
  items: BoardItemState[];
  damageMultiplier: number;
}

export interface BattleEvent {
  at: number;
  actor: 'player' | 'enemy' | 'system';
  text: string;
  amount?: number;
}

export interface BattleSnapshot {
  time: number;
  player: FighterState;
  enemy: FighterState;
  events: BattleEvent[];
  finished: boolean;
  winner: 'player' | 'enemy' | 'draw' | null;
}
