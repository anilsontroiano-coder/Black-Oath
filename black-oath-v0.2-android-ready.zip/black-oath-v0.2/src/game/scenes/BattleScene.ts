import Phaser from 'phaser';
import type { BattleSnapshot, FighterConfig } from '../sim/types';
import { BattleSimulation } from '../sim/battle';

export type BackgroundKey = 'cathedral' | 'forest' | 'camp' | 'fortress';

export class BattleScene extends Phaser.Scene {
  private sim?: BattleSimulation;
  private running = false;
  private latest?: BattleSnapshot;
  private playerConfig?: FighterConfig;
  private enemyConfig?: FighterConfig;
  private bg?: Phaser.GameObjects.Image;
  private overlay?: Phaser.GameObjects.Rectangle;
  private desiredBackground: BackgroundKey = 'cathedral';

  constructor() { super('Battle'); }

  preload() {
    this.load.image('cathedral', '/assets/environment/catedral-luar.png');
    this.load.image('forest', '/assets/environment/floresta-azul.png');
    this.load.image('camp', '/assets/environment/acampamento.png');
    this.load.image('fortress', '/assets/environment/fortaleza.png');
  }

  create() {
    this.bg = this.add.image(this.scale.width / 2, this.scale.height / 2, this.desiredBackground);
    this.bg.setDisplaySize(this.scale.width, this.scale.height).setAlpha(0.72);
    this.overlay = this.add.rectangle(this.scale.width / 2, this.scale.height / 2, this.scale.width, this.scale.height, 0x030611, 0.38);
    this.scale.on('resize', (size: Phaser.Structs.Size) => this.resizeBackground(size.width, size.height));
  }

  private resizeBackground(width: number, height: number) {
    this.bg?.setPosition(width / 2, height / 2).setDisplaySize(width, height);
    this.overlay?.setPosition(width / 2, height / 2).setSize(width, height);
  }

  setBackground(key: BackgroundKey) {
    this.desiredBackground = key;
    if (this.bg && this.textures.exists(key)) {
      this.bg.setTexture(key);
      this.resizeBackground(this.scale.width, this.scale.height);
    }
  }

  startBattle(player: FighterConfig, enemy: FighterConfig) {
    this.playerConfig = player;
    this.enemyConfig = enemy;
    this.sim = new BattleSimulation(player, enemy);
    this.latest = this.sim.snapshot();
    this.running = true;
  }

  update(_: number, deltaMs: number) {
    if (!this.running || !this.sim) return;
    const dt = Math.min(deltaMs / 1000, 0.05);
    this.latest = this.sim.update(dt);
    if (this.latest.finished) this.running = false;
  }

  getSnapshot() { return this.latest; }
  getConfigs() { return { player: this.playerConfig, enemy: this.enemyConfig }; }
}
