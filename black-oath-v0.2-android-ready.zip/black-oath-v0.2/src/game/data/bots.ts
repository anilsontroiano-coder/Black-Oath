import type { FighterConfig, ItemId } from '../sim/types';

type Archetype = { nome: string; itens: ItemId[]; hp: number };

const BOT_TIERS: Archetype[][] = [
  [
    { nome: 'Sombra da Estrada', hp: 82, itens: ['vela_funeraria', 'lamina_desgastada', 'corrente_ferro'] },
    { nome: 'Vigia sem Rosto', hp: 86, itens: ['lanterna_negra', 'lamina_desgastada', 'corrente_ferro'] },
  ],
  [
    { nome: 'Carrasco Errante', hp: 98, itens: ['vela_funeraria', 'machado_carrasco', 'corrente_ferro', 'lamina_desgastada'] },
    { nome: 'Filho do Relógio', hp: 96, itens: ['ampulheta_sem_areia', 'lamina_desgastada', 'corrente_ferro', 'lanterna_negra'] },
  ],
  [
    { nome: 'Tecelão do Vazio', hp: 103, itens: ['porta_lugar_nenhum', 'lanterna_negra', 'ampulheta_sem_areia', 'lamina_desgastada'] },
    { nome: 'Devorador de Amanhãs', hp: 106, itens: ['verme_amanha', 'frasco_meia_noite', 'lanterna_negra', 'machado_carrasco'] },
  ],
  [
    { nome: 'Vigia da Lua Morta', hp: 112, itens: ['lanterna_negra', 'estrela_adormecida', 'corrente_ferro', 'ampulheta_sem_areia'] },
    { nome: 'Herdeiro do Sol Morto', hp: 116, itens: ['fragmento_sol_morto', 'porta_lugar_nenhum', 'corrente_ferro', 'lanterna_negra'] },
  ],
];

export function randomBot(cycle: number, corruption: number): FighterConfig {
  const tier = Math.min(3, Math.max(0, cycle - 1 + Math.floor(corruption / 50)));
  const pool = BOT_TIERS[tier];
  const source = pool[Math.floor(Math.random() * pool.length)];
  const level = Math.max(0, Math.min(2, cycle - 2 + Math.floor(corruption / 45)));
  const upgrades = level === 0 ? undefined : source.itens.map(() => level);
  return {
    nome: `${source.nome} · Ciclo ${cycle}`,
    maxHp: source.hp + Math.max(0, cycle - 1) * 3 + Math.floor(corruption / 30) * 2,
    itemIds: [...source.itens],
    upgrades,
    damageMultiplier: 1 + Math.max(0, cycle - 1) * 0.025 + Math.floor(corruption / 35) * 0.02,
  };
}

export function botIntel(bot: FighterConfig) {
  const counts = new Map<string, number>();
  bot.itemIds.forEach((id) => {
    const category = id.includes('corrente') ? 'Defesa' :
      id.includes('lamina') || id.includes('machado') ? 'Arma' :
      id.includes('estrela') || id.includes('sol') ? 'Cósmico' :
      id.includes('porta') ? 'Vazio' :
      id.includes('ampulheta') || id.includes('verme') ? 'Tempo' : 'Sombrio';
    counts.set(category, (counts.get(category) ?? 0) + 1);
  });
  const primary = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'Desconhecido';
  return [
    `Afinidade principal: ${primary}.`,
    `Vida estimada: ${bot.maxHp}.`,
    `Usa ${bot.itemIds.length} itens no tabuleiro.`,
  ];
}
