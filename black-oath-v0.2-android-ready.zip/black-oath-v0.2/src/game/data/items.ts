import type { ItemDef, ItemId, Rarity } from '../sim/types';

export const ITEMS: Record<ItemId, ItemDef> = {
  lamina_desgastada: {
    id: 'lamina_desgastada', nome: 'Lâmina Desgastada', categoria: 'Arma', raridade: 'Comum',
    cooldown: 6, preco: 5, descricao: 'A cada 6s, causa 12 de dano.', effect: { type: 'damage', amount: 12 },
  },
  vela_funeraria: {
    id: 'vela_funeraria', nome: 'Vela Funerária', categoria: 'Ritual', raridade: 'Comum',
    cooldown: 999, preco: 5, descricao: 'O item à direita carrega 15% mais rápido.', passiveRightHaste: 0.15,
  },
  corrente_ferro: {
    id: 'corrente_ferro', nome: 'Corrente de Ferro', categoria: 'Defesa', raridade: 'Comum',
    cooldown: 8, preco: 5, descricao: 'A cada 8s, recebe 10 de Escudo.', effect: { type: 'shield', amount: 10 },
  },
  lanterna_negra: {
    id: 'lanterna_negra', nome: 'Lanterna Negra', categoria: 'Sombrio', raridade: 'Raro',
    cooldown: 7, preco: 9, descricao: 'A cada 7s, Marca o adversário por 4s.', effect: { type: 'mark', duration: 4 },
  },
  machado_carrasco: {
    id: 'machado_carrasco', nome: 'Machado do Carrasco', categoria: 'Arma', raridade: 'Raro',
    cooldown: 9, preco: 10, descricao: 'A cada 9s, causa 30 de dano.', effect: { type: 'damage', amount: 30 },
  },
  estrela_adormecida: {
    id: 'estrela_adormecida', nome: 'Estrela Adormecida', categoria: 'Cósmico', raridade: 'Épico',
    cooldown: 18, preco: 16, descricao: 'Desperta lentamente e causa 50 de dano.', effect: { type: 'damage', amount: 50 },
  },
  ampulheta_sem_areia: {
    id: 'ampulheta_sem_areia', nome: 'Ampulheta sem Areia', categoria: 'Tempo', raridade: 'Raro',
    cooldown: 10, preco: 9, descricao: 'Adianta em 3s o item ativo mais lento.', effect: { type: 'advanceSlowest', seconds: 3 },
  },
  segundo_coracao: {
    id: 'segundo_coracao', nome: 'Segundo Coração', categoria: 'Carne', raridade: 'Raro',
    cooldown: 6, preco: 10, descricao: 'Abaixo de 50% de Vida, pulsa: você sofre 3 e o inimigo sofre 14.',
    activeBelowHpRatio: 0.5, effect: { type: 'selfDamageDamage', self: 3, target: 14 },
  },
  porta_lugar_nenhum: {
    id: 'porta_lugar_nenhum', nome: 'Porta para Lugar Nenhum', categoria: 'Vazio', raridade: 'Épico',
    cooldown: 12, preco: 17, descricao: 'Faz o item inimigo mais carregado desaparecer por 3s.',
    effect: { type: 'banishEnemy', duration: 3 },
  },
  verme_amanha: {
    id: 'verme_amanha', nome: 'Verme que Devora o Amanhã', categoria: 'Tempo', raridade: 'Épico',
    cooldown: 8, preco: 15, descricao: 'Causa 12 de dano e adianta os itens ao lado em 1s.',
    effect: { type: 'accelerateAdjacent', seconds: 1 },
  },
  frasco_meia_noite: {
    id: 'frasco_meia_noite', nome: 'Frasco da Meia-Noite', categoria: 'Sombrio', raridade: 'Raro',
    cooldown: 9, preco: 10, descricao: 'Adianta todos os itens Sombrios em 2s.',
    effect: { type: 'accelerateCategory', category: 'Sombrio', seconds: 2 },
  },
  fragmento_sol_morto: {
    id: 'fragmento_sol_morto', nome: 'Fragmento do Sol Morto', categoria: 'Cósmico', raridade: 'Lendário',
    cooldown: 6, preco: 24, descricao: 'Acumula 3 cargas e então explode por 56 de dano.',
    effect: { type: 'chargeBlast', charges: 3, amount: 56 },
  },
};

export const ALL_ITEM_IDS = Object.keys(ITEMS) as ItemId[];

const rarityWeight: Record<Rarity, number> = { Comum: 65, Raro: 28, Épico: 6, Lendário: 1 };

export function randomItem(corruption = 0, exclude: ItemId[] = []): ItemId {
  const pool = ALL_ITEM_IDS.filter((id) => !exclude.includes(id));
  const weighted = pool.map((id) => {
    const def = ITEMS[id];
    const corruptionBonus =
      def.raridade === 'Lendário' ? corruption * 0.16 :
      def.raridade === 'Épico' ? corruption * 0.08 :
      def.raridade === 'Raro' ? corruption * 0.03 : 0;
    return { id, weight: rarityWeight[def.raridade] + corruptionBonus };
  });
  const total = weighted.reduce((sum, x) => sum + x.weight, 0);
  let roll = Math.random() * total;
  for (const entry of weighted) {
    roll -= entry.weight;
    if (roll <= 0) return entry.id;
  }
  return weighted[weighted.length - 1].id;
}

export function rarityRank(rarity: Rarity) {
  return ({ Comum: 0, Raro: 1, Épico: 2, Lendário: 3 } as const)[rarity];
}
