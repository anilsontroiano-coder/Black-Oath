import type { FighterConfig, ItemId } from '../sim/types';

export type HuntReward = { gold: number; corruption?: number; itemChance?: number };
export type HuntDef = {
  id: string;
  nome: string;
  perigo: 'Baixo' | 'Médio' | 'Alto';
  descricao: string;
  config: FighterConfig;
  reward: HuntReward;
};

const hunts: HuntDef[] = [
  {
    id: 'rato_tumulo', nome: 'Rato de Túmulo', perigo: 'Baixo',
    descricao: 'Pequeno, faminto e rápido. Uma presa segura.',
    config: { nome: 'Rato de Túmulo', maxHp: 72, itemIds: ['lamina_desgastada', 'corrente_ferro'] as ItemId[] },
    reward: { gold: 4, itemChance: 0.15 },
  },
  {
    id: 'cavaleiro_sem_rosto', nome: 'Cavaleiro sem Rosto', perigo: 'Médio',
    descricao: 'Avança devagar por trás de camadas de ferro morto.',
    config: { nome: 'Cavaleiro sem Rosto', maxHp: 104, itemIds: ['corrente_ferro', 'machado_carrasco', 'lamina_desgastada'] as ItemId[] },
    reward: { gold: 7, itemChance: 0.4 },
  },
  {
    id: 'devorador_velas', nome: 'Devorador de Velas', perigo: 'Alto',
    descricao: 'O tempo trabalha a favor dele. Não deixe a luta se alongar.',
    config: { nome: 'Devorador de Velas', maxHp: 118, itemIds: ['verme_amanha', 'lanterna_negra', 'machado_carrasco', 'corrente_ferro'] as ItemId[], damageMultiplier: 1.08 },
    reward: { gold: 10, corruption: 4, itemChance: 0.7 },
  },
  {
    id: 'santo_oco', nome: 'Santo Oco', perigo: 'Alto',
    descricao: 'Uma estátua que aprendeu a respirar entre orações esquecidas.',
    config: { nome: 'Santo Oco', maxHp: 126, itemIds: ['porta_lugar_nenhum', 'corrente_ferro', 'estrela_adormecida', 'ampulheta_sem_areia'] as ItemId[], damageMultiplier: 1.05 },
    reward: { gold: 11, corruption: 6, itemChance: 0.8 },
  },
];

export function huntChoices(cycle: number, corruption: number): HuntDef[] {
  const shuffled = [...hunts].sort(() => Math.random() - 0.5).slice(0, 3);
  return shuffled.map((hunt) => ({
    ...hunt,
    config: {
      ...hunt.config,
      maxHp: hunt.config.maxHp + (cycle - 1) * 5 + Math.floor(corruption / 25) * 3,
      damageMultiplier: (hunt.config.damageMultiplier ?? 1) + (cycle - 1) * 0.025,
    },
  }));
}
