import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.blackoath.game',
  appName: 'Black Oath',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
