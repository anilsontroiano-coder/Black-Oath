# Gerar o APK do Black Oath pelo celular

Este projeto agora está preparado para virar um aplicativo Android usando Capacitor.

## Opção recomendada: GitHub Actions

Você não precisa instalar Android Studio no celular.

1. Crie um repositório novo no GitHub, por exemplo `black-oath`.
2. Envie todos os arquivos desta pasta para o repositório, mantendo também a pasta `.github/workflows`.
3. Abra a aba **Actions** do repositório.
4. Abra **Gerar APK Android**.
5. Toque em **Run workflow** e depois em **Run workflow** novamente.
6. Quando a execução terminar, abra a execução concluída.
7. Na seção **Artifacts**, baixe **Black-Oath-v0.2-APK**.
8. Extraia o ZIP baixado e instale `Black-Oath-v0.2.apk` no Android.

O APK gerado é um APK de teste/debug e pode ser instalado diretamente no aparelho. Para publicar na Play Store, depois será necessário gerar uma versão release assinada/AAB.

## Como funciona

O jogo continua sendo Phaser + TypeScript + Vite. O Capacitor cria um aplicativo Android nativo que carrega o jogo dentro de uma WebView local, sem precisar hospedar o jogo em um site.

## Arquivos adicionados

- `capacitor.config.ts`: configuração do aplicativo Android.
- `.github/workflows/build-android-apk.yml`: build automático do APK na nuvem.
- Dependências do Capacitor em `package.json`.

## Build em computador, caso queira no futuro

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

O APK fica em:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```
